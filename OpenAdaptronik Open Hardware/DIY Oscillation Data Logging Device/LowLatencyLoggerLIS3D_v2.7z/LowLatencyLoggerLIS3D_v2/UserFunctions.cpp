#include "UserTypes.h"
// User data functions.  Modify these functions for your data items.
RTCZero rtc;

// Time definitions
//RTCZero rtc;
const byte seconds = 0;
byte minutes = 0;
byte hours = 0;
byte day = 12;
byte month = 06;
byte year = 17;
// recording time and date
int rec_minutes;
int rec_hours;
int rec_seconds;
int rec_year;
int rec_month;
int rec_day;

// Start time for data
static uint32_t startMicros;

const uint8_t LIS3D_CS = 10;

const uint8_t LIS3DH_REG_CTRL1 = 0x20;
const uint8_t LIS3DH_REG_CTRL4 = 0x23;

const uint8_t LIS3DH_REG_OUT_X_L = 0x28; //X-Axis Data 0
const uint8_t LIS3DH_REG_OUT_X_H = 0x29; //X-Axis Data 1
const uint8_t LIS3DH_REG_OUT_Y_L = 0x2A; //Y-Axis Data 0
const uint8_t LIS3DH_REG_OUT_Y_H = 0x2B; //Y-Axis Data 1
const uint8_t LIS3DH_REG_OUT_Z_L = 0x2C; //Z-Axis Data 0
const uint8_t LIS3DH_REG_OUT_Z_H = 0x2D; //Z-Axis Data 1

void writeADXL345Register(const uint8_t registerAddress, const uint8_t value) {
  // Max SPI clock frequency is 5 MHz with CPOL = 1 and CPHA = 1.
  SPI.beginTransaction(SPISettings(500000, MSBFIRST, SPI_MODE0));  
  digitalWrite(LIS3D_CS, LOW);
  SPI.transfer(registerAddress);
  SPI.transfer(value);
  digitalWrite(LIS3D_CS, HIGH);
  SPI.endTransaction();  
}

void userSetup() {
  SPI.begin();
  pinMode(LIS3D_CS, OUTPUT);
  digitalWrite(LIS3D_CS, HIGH);

  // enable all axes, high res, 400 Hz
  // ODR3 | ODR2  | ODR1 | ODR0 | LPen | Zen  | Yen | Xen  |
  //   0  |   1   |   1  |   1  |   0  |  1   |  1  |   1  |
  writeADXL345Register(LIS3DH_REG_CTRL1, 0x77);
 
  // High res, BDU enabled, +/- 16G
  // BDU  |  BLE  |  FS1 |  FS0 |   HR | ST1  | ST0 | SIM  |
  //   1  |   0   |   1  |   1  |   1  |  0   |  0  |   0  |
  writeADXL345Register(LIS3DH_REG_CTRL4, 0xB8);  

 // initialize time and date
  rtc.begin();
  rtc.setTime(hours, minutes, seconds);
  rtc.setDate(day, month, year);
}

// Acquire a data record.
void acquireData(data_t* data) {
  // Max SPI clock frequency is 5 MHz with CPOL = 1 and CPHA = 1.
  SPI.beginTransaction(SPISettings(5000000, MSBFIRST, SPI_MODE3));
  data->time = micros();
  digitalWrite(LIS3D_CS, LOW);
  // Read multiple bytes so or 0XC0 with address.
  SPI.transfer(LIS3DH_REG_OUT_X_L | 0XC0);
  data->accel[0] = SPI.transfer(0) | (SPI.transfer(0) << 8);
  data->accel[1] = SPI.transfer(0) | (SPI.transfer(0) << 8);
  data->accel[2] = SPI.transfer(0) | (SPI.transfer(0) << 8); 
  digitalWrite(LIS3D_CS, HIGH);
  SPI.endTransaction();
}

// Print a data record. t,x,y,z
void printData(Print* pr, data_t* data) {
  if (startMicros == 0) {
    startMicros = data->time;
  }
  pr->print(data->time - startMicros);
  for (int i = 0; i < ACCEL_DIM; i++) {
    pr->write(',');
    pr->print(data->accel[i]);
  }
  pr->println();
}

// Get current time
void getCurrentTime() {
  rec_year = rtc.getYear();
  rec_month = rtc.getMonth();
  rec_day = rtc.getDay();
  rec_hours = rtc.getHours();
  rec_minutes = rtc.getMinutes();
  rec_seconds = rtc.getSeconds();
}
// Print data header.
void printHeader(Print* pr) {
  pr->print(F("year,"));
  pr->println(rec_year);
  pr->print(F("month,"));
  pr->println(rec_month);
  pr->print(F("day,"));
  pr->println(rec_day);
  pr->print(F("hour,"));
  pr->println(rec_hours);
  pr->print(F("minutes,"));
  pr->println(rec_minutes);
  pr->print(F("seconds,"));
  pr->println(rec_seconds);
  pr->println(F("sampling rate,250"));
  pr->println(F("frequency unit,Hz"));
  pr->println(F("sampling range,16"));
  pr->println(F("range unit,G"));
  pr->println(F(""));
  startMicros = 0;
  pr->println(F("micros,ax,ay,az"));
}

// Read capacitive pin
//  Input: Arduino pin number
//  Output: Boolean with true if a touch event has been registered
bool readCapacitivePin(int pinToMeasure) {
  noInterrupts();
  bool button_touched = true;
  if (analogRead(pinToMeasure)<1000) { button_touched = false;}
  
  // End of timing-critical section --> enable interrupts again
  interrupts();
  
  // return bool if button was touched
  return button_touched;
}

// set time and date
void setTimeDate() {
  Serial.println(F("Setting up the internal RTC."));
  Serial.print(F("The current time is: "));
  // return current date
  print2digits(rtc.getYear());
  Serial.print(F("/"));
  print2digits(rtc.getMonth());
  Serial.print(F("/"));
  print2digits(rtc.getDay());
  Serial.print(F(" "));

  // ...and time
  print2digits(rtc.getHours());
  Serial.print(F(":"));
  print2digits(rtc.getMinutes());
  Serial.print(F(":"));
  print2digits(rtc.getSeconds());
  Serial.println(F("\nExiting..."));

  // start of setup
  Serial.println(F("Please enter the current hour (24h format)."));
  while (Serial.available() == 0);
  int hours = Serial.parseInt(); //read int or parseFloat for ..float...

  Serial.println(F("Please enter the current minutes."));
  while (Serial.available() == 0);
  int minutes = Serial.parseInt();

  Serial.println(F("Please enter the current year (2 digits)."));
  while (Serial.available() == 0);
  int year = Serial.parseInt();

  Serial.println(F("Please enter the current month."));
  while (Serial.available() == 0);
  int month = Serial.parseInt();
  
  Serial.println(F("Please enter the current day."));
  while (Serial.available() == 0);
  int day = Serial.parseInt();

  // update date and time
  rtc.setTime(hours, minutes, seconds);
  rtc.setDate(day, month, year);

  // return current date
  Serial.print(F("The new time is set to: "));
  print2digits(rtc.getYear());
  Serial.print(F("/"));
  print2digits(rtc.getMonth());
  Serial.print(F("/"));
  print2digits(rtc.getDay());
  Serial.print(F(" "));

  // ...and time
  print2digits(rtc.getHours());
  Serial.print(F(":"));
  print2digits(rtc.getMinutes());
  Serial.print(F(":"));
  print2digits(rtc.getSeconds());
  Serial.println(F("\nExiting..."));
}

//------------------------------------------------------------------------------
// print time and date data
void print2digits(int number) {
  if (number < 10) {
    Serial.print("0"); // print a 0 before if the number is < than 10
  }
  Serial.print(number);
}

