#ifndef UserTypes_h
#define UserTypes_h
#include "Arduino.h"
#include "SPI.h"
#include <RTCZero.h>
#define USE_SHARED_SPI 1
//#define FILE_BASE_NAME "Log"   // careful here, don't choose a too long name --> we set the filename in LowLatencyLogger.ino
// User data types.  Modify for your data items.
const uint8_t ACCEL_DIM = 3;
struct data_t {
  uint32_t time;
  int16_t accel[ACCEL_DIM];
};
// if functions are defined in UserFunctions.cpp, and are used in LowLatencyLogger.ino, then add function name here
void acquireData(data_t* data);
void printData(Print* pr, data_t* data);
void printHeader(Print* pr);
void userSetup();
bool readCapacitivePin(int pinToMeasure);
//void onA1Change();
void getCurrentTime();
void setTimeDate();
void print2digits(int number);
#endif  // UserTypes_h
