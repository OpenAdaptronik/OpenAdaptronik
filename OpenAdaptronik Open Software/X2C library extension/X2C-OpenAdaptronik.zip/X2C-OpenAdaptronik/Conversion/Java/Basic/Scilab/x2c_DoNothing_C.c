// This file is part of X2C. http://www.mechatronic-simulation.org/
// 
// Copyright (c) 2014, Linz Center of Mechatronics GmbH (LCM) http://www.lcm.at/
// All rights reserved.
// 
// Dummy simulation source file
// 

/* include scicos / xcos headers */
#include <scicos.h>
#include <scicos_block4.h>

void x2c_DoNothing_C(scicos_block* block, scicos_flag flag) {
 }
 
 