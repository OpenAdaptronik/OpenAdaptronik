/*
 * Copyright (c) 2018, Linz Center of Mechatronics GmbH (LCM) http://www.lcm.at/
 * All rights reserved.
 */
/*
 * This file is licensed according to the BSD 3-clause license as follows:
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the "Linz Center of Mechatronics GmbH" and "LCM" nor
 *       the names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL "Linz Center of Mechatronics GmbH" BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/*
 * This file is part of X2C. http://www.mechatronic-simulation.org/
 * $LastChangedRevision: 1344 $
 * $LastChangedDate:: 2018-01-10 17:41:37 +0100#$
 */
/* USERCODE-BEGIN:Description                                                                                         */
/* Description: 
Name: NarrowBand_LMS_Controller
Author: Ruo Yi
Principle: Adaptive Controller, which is based on modified LMS algorithm.(Strictly speaking, the function is based on modified FxLMS algorithmus, because the effect of the second path is also considered). In this function, the coefficients of the 2nd-order FIR-Filter are calculated according to the the formular w(n+1)=gamma*w(n)+mu*x'(n)e(n), where x'(n) is the filtered input and mu is the adaptation increment which is determinde by the alpha, the power of input and the P_MIN. For more information about modified LMS-Controller please read the book "Active Noise Control Systems: Algorithms and DSP Implementations" by Sen M. Kuo.
Parameter:
IN1: cos(2*pi*f(n)).
IN2: sin(2*pi*f(n)).
ERROR: the error signal (from error sensor)
ENABLE: switch signal for the controller
OUT1: the coefficient w[1].
OUT2: the coefficient w[2].
ALPHA: the adaptation factor of the modified LMS algorithm.
GAMMA: the leaky factor of the modified LMS algorithm.
P_MIN: the minimal input power.
*/
/* USERCODE-END:Description                                                                                           */
#include "NarrowBand_LMS_Controller_Float32.h"

/* all used update functions to ram for c2000                                                                         */
#if defined(__ALL_UPDATE_FUNC_2_RAM_C2000__)
    #pragma CODE_SECTION(NarrowBand_LMS_Controller_Float32_Update, "ramfuncs")
#endif

/* USERCODE-BEGIN:PreProcessor                                                                                        */
/* Inputs */
#define IN1			(*pTNarrowBand_LMS_Controller_Float32->In1)
#define IN2			(*pTNarrowBand_LMS_Controller_Float32->In2)
#define ERROR		(*pTNarrowBand_LMS_Controller_Float32->E)
#define ENABLE		(*pTNarrowBand_LMS_Controller_Float32->Enable)

/* Outputs */
#define OUT1		(pTNarrowBand_LMS_Controller_Float32->W1)
#define OUT2		(pTNarrowBand_LMS_Controller_Float32->W2)

/* Parameter */
#define	w1							(pTNarrowBand_LMS_Controller_Float32->w1)
#define	w2							(pTNarrowBand_LMS_Controller_Float32->w2)
#define ALPHA						(pTNarrowBand_LMS_Controller_Float32->alpha)
#define GAMMA						(pTNarrowBand_LMS_Controller_Float32->gamma)
#define P_MIN						(pTNarrowBand_LMS_Controller_Float32->p_min)
/* USERCODE-END:PreProcessor                                                                                          */

/**********************************************************************************************************************/
/** Update                                                                                                           **/
/**********************************************************************************************************************/
void NarrowBand_LMS_Controller_Float32_Update(NARROWBAND_LMS_CONTROLLER_FLOAT32 *pTNarrowBand_LMS_Controller_Float32)
{
/* USERCODE-BEGIN:UpdateFnc                                                                                           */
	float32 mu1, mu2, P1, P2, temp1, temp2;
	if (ENABLE != 0) {
		temp1 = IN1 * IN1;
		temp2 = IN2 * IN2;
		if (temp1 >= P_MIN) {
			P1 = temp1;
		}
		else {
			P1 = P_MIN;
		}
		if (temp2 >= P_MIN) {
			P2 = temp2;
		}
		else {
			P2 = P_MIN;
		}
		mu1 = ALPHA / P1;
		mu2 = ALPHA / P2;

		w1 = GAMMA * w1 + mu1 * IN1 * ERROR;
		w2 = GAMMA * w2 + mu2 * IN2 * ERROR;

		OUT1 = w1;
		OUT2 = w2;
	}
	else {
		w1 = 0;
		w2 = 0;
		OUT1 = w1;
		OUT2 = w2;
	}
	
/* USERCODE-END:UpdateFnc                                                                                             */

}

/**********************************************************************************************************************/
/** Initialization                                                                                                   **/
/**********************************************************************************************************************/
void NarrowBand_LMS_Controller_Float32_Init(NARROWBAND_LMS_CONTROLLER_FLOAT32 *pTNarrowBand_LMS_Controller_Float32)
{
    pTNarrowBand_LMS_Controller_Float32->ID = NARROWBAND_LMS_CONTROLLER_FLOAT32_ID;
    pTNarrowBand_LMS_Controller_Float32->W1 = 0;
    pTNarrowBand_LMS_Controller_Float32->W2 = 0;
/* USERCODE-BEGIN:InitFnc                                                                                             */
	w1 = 0;
	w2 = 0;
/* USERCODE-END:InitFnc                                                                                               */
}

/**********************************************************************************************************************/
/** Load block data                                                                                                  **/
/**********************************************************************************************************************/
uint8 NarrowBand_LMS_Controller_Float32_Load(const NARROWBAND_LMS_CONTROLLER_FLOAT32 *pTNarrowBand_LMS_Controller_Float32, uint8 data[], uint16 *dataLength, uint16 maxSize)
{
    uint8 error = (uint8)0;
    if ((uint16)12 > maxSize)
    {
        error = (uint8)1;
    }
    else
    {
        data[0] = (uint8)((*(uint32*)&(pTNarrowBand_LMS_Controller_Float32->alpha)) & 0x000000FF);
        data[1] = (uint8)((*(uint32*)&(pTNarrowBand_LMS_Controller_Float32->alpha) >> 8) & 0x000000FF);
        data[2] = (uint8)((*(uint32*)&(pTNarrowBand_LMS_Controller_Float32->alpha) >> 16) & 0x000000FF);
        data[3] = (uint8)((*(uint32*)&(pTNarrowBand_LMS_Controller_Float32->alpha) >> 24) & 0x000000FF);
        data[4] = (uint8)((*(uint32*)&(pTNarrowBand_LMS_Controller_Float32->gamma)) & 0x000000FF);
        data[5] = (uint8)((*(uint32*)&(pTNarrowBand_LMS_Controller_Float32->gamma) >> 8) & 0x000000FF);
        data[6] = (uint8)((*(uint32*)&(pTNarrowBand_LMS_Controller_Float32->gamma) >> 16) & 0x000000FF);
        data[7] = (uint8)((*(uint32*)&(pTNarrowBand_LMS_Controller_Float32->gamma) >> 24) & 0x000000FF);
        data[8] = (uint8)((*(uint32*)&(pTNarrowBand_LMS_Controller_Float32->p_min)) & 0x000000FF);
        data[9] = (uint8)((*(uint32*)&(pTNarrowBand_LMS_Controller_Float32->p_min) >> 8) & 0x000000FF);
        data[10] = (uint8)((*(uint32*)&(pTNarrowBand_LMS_Controller_Float32->p_min) >> 16) & 0x000000FF);
        data[11] = (uint8)((*(uint32*)&(pTNarrowBand_LMS_Controller_Float32->p_min) >> 24) & 0x000000FF);
        *dataLength = (uint16)12;
/* USERCODE-BEGIN:LoadFnc                                                                                             */
/* USERCODE-END:LoadFnc                                                                                               */
    }
    return (error);
}

/**********************************************************************************************************************/
/** Save block data                                                                                                  **/
/**********************************************************************************************************************/
uint8 NarrowBand_LMS_Controller_Float32_Save(NARROWBAND_LMS_CONTROLLER_FLOAT32 *pTNarrowBand_LMS_Controller_Float32, const uint8 data[], uint16 dataLength)
{
    uint8 error;
    uint32 tmp32;

    if (dataLength != (uint16)12)
    {
        error = (uint8)1;
    }
    else
    {
        tmp32 = (uint32)data[0] + \
            ((uint32)data[1] << 8) + ((uint32)data[2] << 16) + \
            ((uint32)data[3] << 24);
        pTNarrowBand_LMS_Controller_Float32->alpha = (float32)(*(float32*)&tmp32);
        tmp32 = (uint32)data[4] + \
            ((uint32)data[5] << 8) + ((uint32)data[6] << 16) + \
            ((uint32)data[7] << 24);
        pTNarrowBand_LMS_Controller_Float32->gamma = (float32)(*(float32*)&tmp32);
        tmp32 = (uint32)data[8] + \
            ((uint32)data[9] << 8) + ((uint32)data[10] << 16) + \
            ((uint32)data[11] << 24);
        pTNarrowBand_LMS_Controller_Float32->p_min = (float32)(*(float32*)&tmp32);
        error = (uint8)0;
/* USERCODE-BEGIN:SaveFnc                                                                                             */
/* USERCODE-END:SaveFnc                                                                                               */
    }
    return (error);
}

/**********************************************************************************************************************/
/** Get block element address                                                                                        **/
/**********************************************************************************************************************/
#if !defined(NARROWBAND_LMS_CONTROLLER_FLOAT32_ISLINKED)
void* NarrowBand_LMS_Controller_Float32_GetAddress(const NARROWBAND_LMS_CONTROLLER_FLOAT32* block, uint16 elementId)
{
    void* addr;
    switch (elementId)
    {
        case 1:
            addr = (void*)block->In1;
            break;
        case 2:
            addr = (void*)block->In2;
            break;
        case 3:
            addr = (void*)block->E;
            break;
        case 4:
            addr = (void*)block->Enable;
            break;
        case 5:
            addr = (void*)&block->W1;
            break;
        case 6:
            addr = (void*)&block->W2;
            break;
        default:
            addr = (void*)0;
            break;
    }
    return (addr);
}
#endif
