/*
 * Copyright (c) 2018, Linz Center of Mechatronics GmbH (LCM) http://www.lcm.at/
 * All rights reserved.
 */
/*
 * This file is licensed according to the BSD 3-clause license as follows:
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the "Linz Center of Mechatronics GmbH" and "LCM" nor
 *       the names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL "Linz Center of Mechatronics GmbH" BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/*
 * This file is part of X2C. http://www.mechatronic-simulation.org/
 * $LastChangedRevision: 1344 $
 * $LastChangedDate:: 2018-01-10 17:41:37 +0100#$
 */
/* USERCODE-BEGIN:Description                                                                                         */
/* Description:
Name: FIR-Filter
Author: Ruo Yi
Principle: FIR-Filter, which is determined by the coefficients array of W[k].
The transfer function of the FIR-Filter is 
G(z) = W[0]+W[1]*z^(-1)+W[2]*z^(-2)+...W[n-1]*z^(-n+1)
The output is calculated according to 
Out(k) = In(k)*W[0]+In(k-1)W[1]+...+In(k-n+1)*W[n-1]
For more information about the realization of FIR filter in C please read the book "Realisierung digitaler Filter in C" by Carsten Roppel.
Parameter:
COEFFICIENTARRAY: filter coefficients, which are in reverse order. That means, COEFFICIENTARRAY[0]=W[n-1],...,COEFFICIENTARRAY[N-1]=W[0].(This step is already done in Java code)
INPUT_BUFFER: the circular buffer to save input values.	
SIZEARRAY: the length of the FIR-Filter.					
POINTER: Pointer of the circular buffer.					
*/
/* USERCODE-END:Description                                                                                           */
#include "FIR_Filter_Float32.h"

/* all used update functions to ram for c2000                                                                         */
#if defined(__ALL_UPDATE_FUNC_2_RAM_C2000__)
    #pragma CODE_SECTION(FIR_Filter_Float32_Update, "ramfuncs")
#endif

/* USERCODE-BEGIN:PreProcessor                                                                                        */
/* Inputs */
#define IN			(*pTFIR_Filter_Float32->In)

/* Outputs */
#define OUT			(pTFIR_Filter_Float32->Out)

/* Parameter */
#define	COEFFICIENTARRAY			(pTFIR_Filter_Float32->coeffizietArray)
#define	INPUT_BUFFER				(pTFIR_Filter_Float32->input_buffer)
#define SIZEARRAY					(pTFIR_Filter_Float32->sizeArray)
#define POINTER						(pTFIR_Filter_Float32->pointer_buffer)
/* USERCODE-END:PreProcessor                                                                                          */

/**********************************************************************************************************************/
/** Update                                                                                                           **/
/**********************************************************************************************************************/
void FIR_Filter_Float32_Update(FIR_FILTER_FLOAT32 *pTFIR_Filter_Float32)
{
/* USERCODE-BEGIN:UpdateFnc                                                                                           */
	uint16 i;
	float32 summation = 0;
	
	INPUT_BUFFER[POINTER] = IN;

	POINTER = (POINTER + 1) % SIZEARRAY;

	for (i = 0; i < SIZEARRAY; i++) {
		summation += (COEFFICIENTARRAY[i] * INPUT_BUFFER[(POINTER + i) % SIZEARRAY]);
	}
	OUT = summation;

/* USERCODE-END:UpdateFnc                                                                                             */

}

/**********************************************************************************************************************/
/** Initialization                                                                                                   **/
/**********************************************************************************************************************/
void FIR_Filter_Float32_Init(FIR_FILTER_FLOAT32 *pTFIR_Filter_Float32)
{
    pTFIR_Filter_Float32->ID = FIR_FILTER_FLOAT32_ID;
    pTFIR_Filter_Float32->Out = 0;
/* USERCODE-BEGIN:InitFnc                                                                                             */
	uint16 i;
	for (i = 0; i < 500; i++) {
		INPUT_BUFFER[i] = 0;
	}
	POINTER = 0;
/* USERCODE-END:InitFnc                                                                                               */
}

/**********************************************************************************************************************/
/** Load block data                                                                                                  **/
/**********************************************************************************************************************/
uint8 FIR_Filter_Float32_Load(const FIR_FILTER_FLOAT32 *pTFIR_Filter_Float32, uint8 data[], uint16 *dataLength, uint16 maxSize)
{
    uint8 error = (uint8)0;
    if ((uint16)2 > maxSize)
    {
        error = (uint8)1;
    }
    else
    {
        data[0] = (uint8)(pTFIR_Filter_Float32->sizeArray & 0x00FF);
        data[1] = (uint8)((pTFIR_Filter_Float32->sizeArray >> 8) & 0x00FF);
        *dataLength = (uint16)2;
/* USERCODE-BEGIN:LoadFnc                                                                                             */
/* USERCODE-END:LoadFnc                                                                                               */
    }
    return (error);
}

/**********************************************************************************************************************/
/** Save block data                                                                                                  **/
/**********************************************************************************************************************/
uint8 FIR_Filter_Float32_Save(FIR_FILTER_FLOAT32 *pTFIR_Filter_Float32, const uint8 data[], uint16 dataLength)
{
    uint8 error;

    if (dataLength != (uint16)2)
    {
        error = (uint8)1;
    }
    else
    {
        pTFIR_Filter_Float32->sizeArray = ((uint16)data[0] + \
            ((uint16)data[1] << 8));
        error = (uint8)0;
/* USERCODE-BEGIN:SaveFnc                                                                                             */
/* USERCODE-END:SaveFnc                                                                                               */
    }
    return (error);
}

/**********************************************************************************************************************/
/** Get block element address                                                                                        **/
/**********************************************************************************************************************/
#if !defined(FIR_FILTER_FLOAT32_ISLINKED)
void* FIR_Filter_Float32_GetAddress(const FIR_FILTER_FLOAT32* block, uint16 elementId)
{
    void* addr;
    switch (elementId)
    {
        case 1:
            addr = (void*)block->In;
            break;
        case 2:
            addr = (void*)&block->Out;
            break;
        default:
            addr = (void*)0;
            break;
    }
    return (addr);
}
#endif
