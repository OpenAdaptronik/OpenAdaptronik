/*
 * Copyright (c) {YEAR}, {ORGANIZATION_NAME}, {ORGANIZATION_WEB}
 * All rights reserved.
 */
/*
 * This file is licensed according to the BSD 3-clause license as follows:
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *   * Neither the name of the "{ORGANIZATION_NAME}" nor
 *     the names of its contributors may be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL "{ORGANIZATION_NAME}" BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/*
 * This file is part of X2C. http://www.mechatronic-simulation.org/
 * $LastChangedRevision$
 */
/* USERCODE-BEGIN:Description                                                                                         */
/* Description: 
	Name: PrbsGen
	Author: Ruo Yi
	Description: This is the Source-Code of the X2C-Block function "PrbsGen". This Block generates the Pseudo Random Binary Sequence(PRBS). User can set the length of the Pseudo Random Binary Sequence by choosing the bits number of the Shift Register. There are three bits number to choose from: 7 bits, 9 bits and 11 bits. In addition to the length, user can set the amplitude, offset and the cycle time of the sequence. The cycle time is set like this: cycle time = sample time * sample multiplier.
	Principle: 
	Use Linear Feedback Shift Register(LFSR) to generate Pseudo Random Binary Sequence(PRBS).
	For example, a LFSR contains 11 bits, the second and the 11th bit will be logical processed through a XOR element.
	After each simple time, the numbers in the register are shifted 1 digit to the right, and the rightmost digit is the output value.

									+---+---+---+---+---+---+---+---+---+---+---+
							+------>| 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |------->out
							|		+---+---+---+---+---+---+---+---+---+---+---+
							|			  |									  |
							|			  |								 	  |
							|			  |									  |
							|	 +---+<---+ 								  |
							+----|XOR|										  |
								 +---+<---------------------------------------+
	Parameter:
	OFFSET: the offset of the output.
	AMPLITUDE: the amplitude of the output.
	LFSR: Linear Feedback Shift Register.
	BITNUM: the bit number of LFSR.
	SAMPLEMULTIPLIER: the multiple factor of base sample time.
	CYCLENUM: the counter for recording delay period.
	OUT_OLD: the privious value of output.
*/

/* USERCODE-END:Description                                                                                           */
#include "PrbsGen_Float32.h"

/* all used update functions to ram for c2000                                                                         */
#if defined(__ALL_UPDATE_FUNC_2_RAM_C2000__)
    #pragma CODE_SECTION(PrbsGen_Float32_Update, "ramfuncs")
#endif

/* USERCODE-BEGIN:PreProcessor                                                                                        */
/* Input */
#define ENABLE		(*pTPrbsGen_Float32->Enable)

/* Output */  
#define OUT		 	(pTPrbsGen_Float32->Out)

/* Parameter */
#define OFFSET					(pTPrbsGen_Float32->offset)
#define AMPLITUDE				(pTPrbsGen_Float32->amplitude)
#define LFSR					(pTPrbsGen_Float32->lfsr)
#define BITNUM					(pTPrbsGen_Float32->bitnum)
#define SAMPLEMULTIPLIER		(pTPrbsGen_Float32->sampleMultiplier)
#define CYCLENUM				(pTPrbsGen_Float32->cycleNum)
#define OUT_OLD					(pTPrbsGen_Float32->out_old)
/* USERCODE-END:PreProcessor                                                                                          */

/**********************************************************************************************************************/
/** Update                                                                                                           **/
/**********************************************************************************************************************/
void PrbsGen_Float32_Update(PRBSGEN_FLOAT32 *pTPrbsGen_Float32)
{
/* USERCODE-BEGIN:UpdateFnc                                                                                           */
	uint16 bit;
	if (ENABLE != 0) {
		if (CYCLENUM  % SAMPLEMULTIPLIER == 0) {
			if (BITNUM == 7) { 
				OUT = (float32)(LFSR & 0x0001) * AMPLITUDE + OFFSET;
				OUT_OLD = OUT;
				//the first (from right to left) and the 7th bit will be logical processed through a XOR element.
				bit = ((LFSR >> 0) ^ (LFSR >> 6)) & 0x0001; 
				//the wohle LFSR will be shifted to right by one bit and the 7th (from right to left) bit will be replaced by the output of the XOR element.
				LFSR = (float32)((LFSR >> 1) | (bit << 6)); 
			}
			else if (BITNUM == 9) {
				OUT = (float32)(LFSR & 0x0001) * AMPLITUDE + OFFSET;
				OUT_OLD = OUT;
				//the first (from right to left) and the 6th bit will be logical processed through a XOR element.
				bit = ((LFSR >> 0) ^ (LFSR >> 5)) & 0x0001;
				//the wohle LFSR will be shifted to right by one bit and the 9th (from right to left) bit will be replaced by the output of the XOR element.
				LFSR = (float32)((LFSR >> 1) | (bit << 8));
			}
			else {
				OUT = (float32)(LFSR & 0x0001) * AMPLITUDE + OFFSET;
				OUT_OLD = OUT;
				//the first (from right to left) and the 10th bit will be logical processed through a XOR element.
				bit = ((LFSR >> 0) ^ (LFSR >> 9)) & 0x0001;
				//the wohle LFSR will be shifted to right by one bit and the 11th (from right to left) bit will be replaced by the output of the XOR element.
				LFSR = (float32)((LFSR >> 1) | (bit << 10));
			}
		}
		else {
			OUT = OUT_OLD;
		}
		CYCLENUM = (CYCLENUM + 1) % SAMPLEMULTIPLIER;
	}else {
		if (BITNUM == 7) {
			LFSR = 0x007F;		//Initial value of LFSR is 111 1111(7 bits)
		}
		else if (BITNUM == 9) {
			LFSR = 0x01FF;		//Initial value of LFSR is 1 1111 1111(9 bits)
		}
		else {
			LFSR = 0x07FF;		//Initial value of LFSR is 111 1111 1111(11 bits)
		}
		CYCLENUM = 0;
		OUT = 0;
	}
	
/* USERCODE-END:UpdateFnc                                                                                             */

}

/**********************************************************************************************************************/
/** Initialization                                                                                                   **/
/**********************************************************************************************************************/
void PrbsGen_Float32_Init(PRBSGEN_FLOAT32 *pTPrbsGen_Float32)
{
    pTPrbsGen_Float32->ID = PRBSGEN_FLOAT32_ID;
    pTPrbsGen_Float32->Out = 0;
/* USERCODE-BEGIN:InitFnc                                                                                             */
	CYCLENUM = 0;
	if (BITNUM == 7) {
		LFSR = 0x007F;		//Initial value of LFSR is 111 1111(7 bits)
	}
	else if (BITNUM == 9) {
		LFSR = 0x01FF;		//Initial value of LFSR is 1 1111 1111(9 bits)
	}
	else{
		LFSR = 0x07FF;		//Initial value of LFSR is 111 1111 1111(11 bits)
	}
	OUT_OLD = 0;
	
/* USERCODE-END:InitFnc                                                                                               */
}

/**********************************************************************************************************************/
/** Load block data                                                                                                  **/
/**********************************************************************************************************************/
uint8 PrbsGen_Float32_Load(const PRBSGEN_FLOAT32 *pTPrbsGen_Float32, uint8 data[], uint16 *dataLength, uint16 maxSize)
{
    uint8 error = (uint8)0;
    if ((uint16)10 > maxSize)
    {
        error = (uint8)1;
    }
    else
    {
        data[0] = (uint8)((*(uint32*)&(pTPrbsGen_Float32->amplitude)) & 0x000000FF);
        data[1] = (uint8)((*(uint32*)&(pTPrbsGen_Float32->amplitude) >> 8) & 0x000000FF);
        data[2] = (uint8)((*(uint32*)&(pTPrbsGen_Float32->amplitude) >> 16) & 0x000000FF);
        data[3] = (uint8)((*(uint32*)&(pTPrbsGen_Float32->amplitude) >> 24) & 0x000000FF);
        data[4] = (uint8)((*(uint32*)&(pTPrbsGen_Float32->offset)) & 0x000000FF);
        data[5] = (uint8)((*(uint32*)&(pTPrbsGen_Float32->offset) >> 8) & 0x000000FF);
        data[6] = (uint8)((*(uint32*)&(pTPrbsGen_Float32->offset) >> 16) & 0x000000FF);
        data[7] = (uint8)((*(uint32*)&(pTPrbsGen_Float32->offset) >> 24) & 0x000000FF);
        data[8] = (uint8)pTPrbsGen_Float32->bitnum;
        data[9] = (uint8)pTPrbsGen_Float32->sampleMultiplier;
        *dataLength = (uint16)10;
/* USERCODE-BEGIN:LoadFnc                                                                                             */
/* USERCODE-END:LoadFnc                                                                                               */
    }
    return (error);
}

/**********************************************************************************************************************/
/** Save block data                                                                                                  **/
/**********************************************************************************************************************/
uint8 PrbsGen_Float32_Save(PRBSGEN_FLOAT32 *pTPrbsGen_Float32, const uint8 data[], uint16 dataLength)
{
    uint8 error;
    uint32 tmp32;

    if (dataLength != (uint16)10)
    {
        error = (uint8)1;
    }
    else
    {
        tmp32 = (uint32)data[0] + \
            ((uint32)data[1] << 8) + ((uint32)data[2] << 16) + \
            ((uint32)data[3] << 24);
        pTPrbsGen_Float32->amplitude = (float32)(*(float32*)&tmp32);
        tmp32 = (uint32)data[4] + \
            ((uint32)data[5] << 8) + ((uint32)data[6] << 16) + \
            ((uint32)data[7] << 24);
        pTPrbsGen_Float32->offset = (float32)(*(float32*)&tmp32);
        pTPrbsGen_Float32->bitnum = ((uint8)data[8]);
        pTPrbsGen_Float32->sampleMultiplier = ((uint8)data[9]);
        error = (uint8)0;
/* USERCODE-BEGIN:SaveFnc                                                                                             */
/* USERCODE-END:SaveFnc                                                                                               */
    }
    return (error);
}

/**********************************************************************************************************************/
/** Get block element address                                                                                        **/
/**********************************************************************************************************************/
#if !defined(PRBSGEN_FLOAT32_ISLINKED)
void* PrbsGen_Float32_GetAddress(const PRBSGEN_FLOAT32* block, uint16 elementId)
{
    void* addr;
    switch (elementId)
    {
        case 1:
            addr = (void*)block->Enable;
            break;
        case 2:
            addr = (void*)&block->Out;
            break;
        default:
            addr = (void*)0;
            break;
    }
    return (addr);
}
#endif
