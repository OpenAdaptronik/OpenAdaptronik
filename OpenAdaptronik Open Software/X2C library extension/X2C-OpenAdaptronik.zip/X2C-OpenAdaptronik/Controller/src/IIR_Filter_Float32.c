/*
 * Copyright (c) 2018, Linz Center of Mechatronics GmbH (LCM) http://www.lcm.at/
 * All rights reserved.
 */
/*
 * This file is licensed according to the BSD 3-clause license as follows:
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the "Linz Center of Mechatronics GmbH" and "LCM" nor
 *       the names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL "Linz Center of Mechatronics GmbH" BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/*
 * This file is part of X2C. http://www.mechatronic-simulation.org/
 * $LastChangedRevision: 1344 $
 * $LastChangedDate:: 2018-01-10 17:41:37 +0100#$
 */
/* USERCODE-BEGIN:Description */
/* Description: 
Name: IIR-Filter
Author: Ruo Yi
Princinple; IIR-Filter, which is determined by the coefficients array of A[k] and B[k].
The transfer function of the IIR-Filter is
         b[n] + b[n-1]z^(-1) + ... + b[0]z^(-n)
G(z) = ------------------------------------------
         1 + a[n-1]z^(-1) + ... + a[0]z^(-n)
For more information about IIR filter please read the book "Realisierung digitaler Filter in C" by Carsten Roppel.
Parameter:
COEFFICIENT_A: array for the denominator coefficients of the IIR-Filter, which are in reverse order.(This step is already done in Java code)
COEFFICIENT_B: array for the numerator coefficients of the IIR-Filter, which are in reverse order.(This step is already done in Java code)
ORDER: the order of the Filter.
POINTER_A: Pointer of the circular buffer "OUTPUT_BUFFER".
POINTER_B: Pointer of the circular buffer "INPUT_BUFFER".
INPUT_BUFFER: the circular buffer to save input values.
OUTPUT_BUFFER: the circular buffer to save output values.
OUT_OLD: the privious value of output.
*/
/* USERCODE-END:Description                                                                                           */
#include "IIR_Filter_Float32.h"

/* all used update functions to ram for c2000                                                                         */
#if defined(__ALL_UPDATE_FUNC_2_RAM_C2000__)
    #pragma CODE_SECTION(IIR_Filter_Float32_Update, "ramfuncs")
#endif

/* USERCODE-BEGIN:PreProcessor                                                                                        */
/* Inputs */
#define IN			(*pTIIR_Filter_Float32->In)

/* Outputs */
#define OUT			(pTIIR_Filter_Float32->Out)

/* Parameter */
#define	COEFFICIENT_A				(pTIIR_Filter_Float32->coefficientA)
#define	COEFFICIENT_B				(pTIIR_Filter_Float32->coefficientB)
#define ORDER						(pTIIR_Filter_Float32->order)
#define POINTER_A					(pTIIR_Filter_Float32->pointer_bufferA)
#define POINTER_B					(pTIIR_Filter_Float32->pointer_bufferB)
#define INPUT_BUFFER				(pTIIR_Filter_Float32->input_buffer)
#define OUTPUT_BUFFER				(pTIIR_Filter_Float32->output_buffer)
#define OUT_OLD						(pTIIR_Filter_Float32->out_old)
/* USERCODE-END:PreProcessor                                                                                          */

/**********************************************************************************************************************/
/** Update                                                                                                           **/
/**********************************************************************************************************************/
void IIR_Filter_Float32_Update(IIR_FILTER_FLOAT32 *pTIIR_Filter_Float32)
{
/* USERCODE-BEGIN:UpdateFnc                                                                                           */
	uint16 i;
	float32 summation = 0;

	INPUT_BUFFER[POINTER_B] = IN;
	OUTPUT_BUFFER[POINTER_A] = OUT_OLD;

	POINTER_B = (POINTER_B + 1) % ORDER;
	POINTER_A = (POINTER_A + 1) % (ORDER - 1);

	// Nummerator of the transfer function
	for (i = 0; i < ORDER; i++) {
		summation += (COEFFICIENT_B[i] * INPUT_BUFFER[(POINTER_B + i) % ORDER]);
	}
	// Denominator of the transfer function
	for (i = 0; i < (ORDER - 1); i++) {
		summation -= (COEFFICIENT_A[i] * OUTPUT_BUFFER[(POINTER_A + i) % (ORDER - 1)]);
	}
	OUT = summation;
	OUT_OLD = OUT;

/* USERCODE-END:UpdateFnc                                                                                             */

}

/**********************************************************************************************************************/
/** Initialization                                                                                                   **/
/**********************************************************************************************************************/
void IIR_Filter_Float32_Init(IIR_FILTER_FLOAT32 *pTIIR_Filter_Float32)
{
    pTIIR_Filter_Float32->ID = IIR_FILTER_FLOAT32_ID;
    pTIIR_Filter_Float32->Out = 0;
/* USERCODE-BEGIN:InitFnc                                                                                             */
	POINTER_A = 0;
	POINTER_B = 0;
	OUT_OLD = 0;
	uint16 i;
	for (i = 0; i < 50; i++) {
		INPUT_BUFFER[i] = 0;
		OUTPUT_BUFFER[i] = 0;
	}
/* USERCODE-END:InitFnc                                                                                               */
}

/**********************************************************************************************************************/
/** Load block data                                                                                                  **/
/**********************************************************************************************************************/
uint8 IIR_Filter_Float32_Load(const IIR_FILTER_FLOAT32 *pTIIR_Filter_Float32, uint8 data[], uint16 *dataLength, uint16 maxSize)
{
    uint8 error = (uint8)0;
    if ((uint16)1 > maxSize)
    {
        error = (uint8)1;
    }
    else
    {
        data[0] = (uint8)pTIIR_Filter_Float32->order;
        *dataLength = (uint16)1;
/* USERCODE-BEGIN:LoadFnc                                                                                             */
/* USERCODE-END:LoadFnc                                                                                               */
    }
    return (error);
}

/**********************************************************************************************************************/
/** Save block data                                                                                                  **/
/**********************************************************************************************************************/
uint8 IIR_Filter_Float32_Save(IIR_FILTER_FLOAT32 *pTIIR_Filter_Float32, const uint8 data[], uint16 dataLength)
{
    uint8 error;
    uint32 tmp32;

    if (dataLength != (uint16)1)
    {
        error = (uint8)1;
    }
    else
    {
        pTIIR_Filter_Float32->order = ((uint8)data[0]);
        error = (uint8)0;
/* USERCODE-BEGIN:SaveFnc                                                                                             */
/* USERCODE-END:SaveFnc                                                                                               */
    }
    return (error);
}

/**********************************************************************************************************************/
/** Get block element address                                                                                        **/
/**********************************************************************************************************************/
#if !defined(IIR_FILTER_FLOAT32_ISLINKED)
void* IIR_Filter_Float32_GetAddress(const IIR_FILTER_FLOAT32* block, uint16 elementId)
{
    void* addr;
    switch (elementId)
    {
        case 1:
            addr = (void*)block->In;
            break;
        case 2:
            addr = (void*)&block->Out;
            break;
        default:
            addr = (void*)0;
            break;
    }
    return (addr);
}
#endif
